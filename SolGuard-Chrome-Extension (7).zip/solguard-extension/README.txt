SOLGUARD — EXTENSÃO CHROME

Como instalar:
1. Extraia o arquivo ZIP em uma pasta.
2. No Chrome, abra chrome://extensions.
3. Ative “Modo do desenvolvedor” no canto superior direito.
4. Clique em “Carregar sem compactação”.
5. Escolha a pasta solguard-extension extraída.
6. Fixe o ícone SolGuard na barra do Chrome.

Para demonstrar:
- Cole: solana:5Y4DemoAddressA1p?amount=0.5&label=Solana%20Store%20Brasil
  Resultado: destinatário correspondente.
- Cole: solana:9xQFraudAddressZ7k?amount=0.5&label=Solana%20Store%20Brasil
  Resultado: alerta de divergência.

Este é um MVP demonstrativo. A lista de destinatários confiáveis está no arquivo popup.js.
