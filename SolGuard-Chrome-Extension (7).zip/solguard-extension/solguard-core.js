/* Shared analysis routines. This file is intentionally dependency-free for MV3. */
(function (root) {
  const BASE58='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  function validAddress(value) {
    if(typeof value!=='string'||value.length<32||value.length>44||![...value].every(c=>BASE58.includes(c))) return false;
    let leading=0; while(value[leading]==='1') leading++;
    const bytes=[];
    for(const char of value.slice(leading)){let carry=BASE58.indexOf(char);for(let i=0;i<bytes.length;i++){const n=bytes[i]*58+carry;bytes[i]=n&255;carry=n>>8}while(carry){bytes.push(carry&255);carry>>=8}}
    return leading+bytes.length===32;
  }
  function parse(input,source='pagamento') {
    try { if(typeof input!=='string') return null; const raw=input.trim();
      if(/^solana:/i.test(raw)){const body=raw.slice(7),q=body.indexOf('?'),address=decodeURIComponent(q<0?body:body.slice(0,q)),params=new URLSearchParams(q<0?'':body.slice(q+1));if(!validAddress(address))return null;const amount=params.get('amount');if(amount!==null&&(!/^\d+(\.\d+)?$/.test(amount)||Number(amount)<=0))return null;return{address,amount:amount||null,token:params.get('spl-token')||'SOL',source}}
      return validAddress(raw)?{address:raw,amount:null,token:'SOL',source}:null;
    } catch { return null; }
  }
  function compareSources(page,qr,registry) {
    const checks=[]; if(!page&&!qr)return{level:'none',title:'Nenhum pagamento compatível identificado',reason:'Não encontramos um endereço Solana válido.',checks};
    const payment=page||qr;checks.push({name:'Pagamento detectado',status:'ok',detail:payment.source});
    if(page&&qr){if(page.address!==qr.address)return{level:'red',title:'Divergência suspeita detectada',reason:'O QR Code aponta para um destinatário diferente do endereço exibido no checkout.',payment,page,qr,checks:[...checks,{name:'Destinatário',status:'fail',detail:'QR Code diferente do texto'}]};checks.push({name:'Destinatário',status:'ok',detail:'QR Code e texto correspondem'});if(page.amount&&qr.amount&&page.amount!==qr.amount)return{level:'red',title:'Divergência suspeita detectada',reason:'O valor do QR Code é diferente do valor exibido no checkout.',payment,page,qr,checks:[...checks,{name:'Valor',status:'fail',detail:page.amount+' ≠ '+qr.amount}]};checks.push({name:'Valor',status:page.amount&&qr.amount?'ok':'unknown',detail:page.amount&&qr.amount?'Valores correspondem':'Valor não disponível nos dois locais'})}else checks.push({name:'QR Code',status:'unknown',detail:'Não foi possível confirmar o conteúdo do QR Code'});
    const expected=registry&&registry[payment.address];if(expected&&(!expected.token||expected.token===payment.token))return{level:'green',title:'Identidade confirmada por referência',reason:'O endereço corresponde a uma referência independente configurada na extensão.',payment,page,qr,checks:[...checks,{name:'Referência independente',status:'ok',detail:expected.name}]};
    return{level:'yellow',title:page&&qr?'Dados do pagamento consistentes':'Verificação inconclusiva',reason:page&&qr?'Endereço e dados disponíveis são consistentes. Isso não confirma a identidade da loja nem substitui uma referência independente.':'Pagamento detectado, mas faltam dados para comparar com uma referência independente.',payment,page,qr,checks:[...checks,{name:'Referência independente',status:'unknown',detail:'Não cadastrada — comum em carteiras únicas por pedido'}]};
  }
  root.SolGuardDetector={validAddress,parse,compareSources};
})(globalThis);
