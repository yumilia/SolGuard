// Service worker do SolGuard. Tudo é processado localmente; nada é enviado para servidores externos.
const SHOT_MIN_MS = 3000;
const lastShot = new Map();
let queue = Promise.resolve();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !sender.tab) return;
  let task;
  if (msg.type === 'analysis') task = saveAnalysis(sender.tab.id, sender.frameId, msg.data);
  else if (msg.type === 'loadJsQR') task = loadJsQR(sender);
  else if (msg.type === 'capture') task = capture(sender);
  else if (msg.type === 'fetchImage') task = fetchImage(msg.url);
  else return;
  task.then(sendResponse, () => sendResponse({ ok: false }));
  return true;
});

// Resultado por aba (e por frame), guardado só em memória de sessão.
function saveAnalysis(tabId, frameId, data) {
  queue = queue.then(async () => {
    const key = 'analysis:' + tabId;
    const cur = (await chrome.storage.session.get(key))[key] || {};
    if (!data || data.level === 'none') delete cur[frameId]; else cur[frameId] = data;
    if (Object.keys(cur).length) await chrome.storage.session.set({ [key]: cur });
    else await chrome.storage.session.remove(key);
    return { ok: true };
  }).catch(() => ({ ok: false }));
  return queue;
}

chrome.tabs.onRemoved.addListener(id => { chrome.storage.session.remove('analysis:' + id); lastShot.delete(id); });
chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === 'loading') chrome.storage.session.remove('analysis:' + id); });

// A biblioteca de leitura de QR só é injetada em páginas que parecem de pagamento Solana.
async function loadJsQR(sender) {
  try {
    await chrome.scripting.executeScript({ target: { tabId: sender.tab.id, frameIds: [sender.frameId] }, files: ['jsQR.js'] });
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: String((e && e.message) || e) };
  }
}

// Captura da aba visível, para QR que não dá para ler direto do DOM.
async function capture(sender) {
  const tab = sender.tab;
  if (!tab.active) return { ok: false, reason: 'inactive' };
  const now = Date.now();
  if (now - (lastShot.get(tab.id) || 0) < SHOT_MIN_MS) return { ok: false, reason: 'throttled' };
  lastShot.set(tab.id, now);
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    return { ok: true, dataUrl };
  } catch (e) {
    return { ok: false, reason: String((e && e.message) || e) };
  }
}

// Baixa uma imagem de outro domínio (sem cookies) para que o QR possa ser decodificado.
async function fetchImage(url) {
  try {
    const u = new URL(url);
    if (!/^https?:$/.test(u.protocol)) return { ok: false };
    const res = await fetch(u.href, { credentials: 'omit' });
    if (!res.ok) return { ok: false };
    const type = (res.headers.get('content-type') || '').split(';')[0].trim();
    if (!/^image\//.test(type)) return { ok: false };
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length > 5e6) return { ok: false };
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return { ok: true, dataUrl: 'data:' + type + ';base64,' + btoa(bin) };
  } catch {
    return { ok: false };
  }
}
