(function (root) {
  const BASE58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

  // Referência de endereços já conhecidos (edite com os seus).
  const DEFAULT_REGISTRY = {
    '11111111111111111111111111111111': { name: 'Solana Store Demo' }
  };

  function validAddress(value) {
    if (typeof value !== 'string' || value.length < 32 || value.length > 44 || ![...value].every(c => BASE58.includes(c))) return false;
    let leading = 0; while (value[leading] === '1') leading++;
    const bytes = [];
    for (const char of value.slice(leading)) {
      let carry = BASE58.indexOf(char);
      for (let i = 0; i < bytes.length; i++) {
        const n = bytes[i] * 58 + carry;
        bytes[i] = n & 255;
        carry = n >> 8;
      }
      while (carry) {
        bytes.push(carry & 255);
        carry >>= 8;
      }
    }
    return leading + bytes.length === 32;
  }

  function parse(input, source = 'pagamento') {
    try {
      if (typeof input !== 'string') return null;
      const raw = input.trim();
      if (/^solana:/i.test(raw)) {
        const body = raw.slice(7), q = body.indexOf('?'), address = decodeURIComponent(q < 0 ? body : body.slice(0, q)), params = new URLSearchParams(q < 0 ? '' : body.slice(q + 1));
        if (!validAddress(address)) return null;
        const amount = params.get('amount');
        if (amount !== null && (!/^\d+(\.\d+)?$/.test(amount) || Number(amount) <= 0)) return null;
        const splToken = params.get('spl-token') || null;
        return { address, amount: amount || null, token: splToken || 'SOL', splToken, source };
      }
      if (/^https?:\/\//i.test(raw)) {
        try {
          const url = new URL(raw);
          const params = url.searchParams;
          const targetAddress = params.get('to') || params.get('recipient') || params.get('destination') || params.get('address') || params.get('wallet');
          if (targetAddress && validAddress(targetAddress)) {
            const amount = params.get('amount') || params.get('value') || params.get('price');
            const splToken = params.get('spl-token') || null;
            return { address: targetAddress, amount: amount || null, token: params.get('token') || splToken || 'SOL', splToken, source: source + ' (gateway)' };
          }
        } catch {}
      }
      return validAddress(raw) ? { address: raw, amount: null, token: 'SOL', splToken: null, source } : null;
    } catch {
      return null;
    }
  }

  // ---- Extração a partir do texto da página ----
  const B58C = '[1-9A-HJ-NP-Za-km-z]';
  // Fronteiras evitam "cortar" strings base58 maiores (ex.: hash de transação) e achar endereço falso.
  const ADDR_RE = new RegExp('(?<!' + B58C + ')' + B58C + '{32,44}(?!' + B58C + ')', 'g');
  const LABEL_RE = /(endere[cç]o|address|carteira|wallet|destinat[aá]rio|recipient|enviar para|send to)/gi;
  const AMOUNT = '([0-9]+(?:[.,][0-9]+)?)\\s*(SOL|USDC|USDT)\\b';

  function extractFromText(text) {
    text = String(text || '');
    const occ = [];
    for (const m of text.matchAll(ADDR_RE)) if (validAddress(m[0])) occ.push({ address: m[0], index: m.index });
    const addresses = [...new Set(occ.map(o => o.address))];

    // Endereço "principal": o primeiro que aparece logo depois de um rótulo (Endereço, Carteira, Wallet...).
    let primary = null;
    for (const l of text.matchAll(LABEL_RE)) {
      const hit = occ.find(o => o.index > l.index && o.index - l.index < 250);
      if (hit) { primary = hit.address; break; }
    }
    if (!primary && occ.length) primary = occ[0].address;

    const m = text.match(new RegExp('(?:valor|amount|total|pagar|pay)[\\s:\\-]{0,20}' + AMOUNT, 'i')) || text.match(new RegExp(AMOUNT, 'i'));
    return { addresses, primary, amount: m ? m[1].replace(',', '.') : null, token: m ? m[2].toUpperCase() : null };
  }

  // ---- Comparação ----
  const short = a => a.slice(0, 4) + '…' + a.slice(-4);
  const sameAmount = (a, b) => Math.abs(Number(a) - Number(b)) < 1e-9;

  function compareSources(page, qr, registry, ctx = {}) {
    const checks = [];
    if (!page && !qr) return { level: 'none', title: 'Nenhum pagamento compatível identificado', reason: 'Não encontramos um endereço Solana válido.', checks };
    const payment = page || qr;
    checks.push({ name: 'Pagamento detectado', status: 'ok', detail: payment.source });
    if (qr && ctx.how) checks.push({ name: 'Leitura do QR', status: 'info', detail: ctx.how });
    const base = { payment, page, qr, checks };
    const known = registry && registry[payment.address];

    if (page && qr) {
      if (page.address !== qr.address) {
        const also = (page.all || []).includes(qr.address);
        checks.push({ name: 'Destinatário', status: 'fail', detail: 'QR → ' + short(qr.address) + ' · página → ' + short(page.address) });
        return { ...base, level: 'red', title: 'Divergência suspeita detectada', reason: 'O QR Code leva a ' + qr.address + ', mas a página indica ' + page.address + (also ? ' (o endereço do QR aparece em outro ponto da página).' : '.') + ' Não envie o pagamento.' };
      }
      checks.push({ name: 'Destinatário', status: 'ok', detail: 'QR Code e endereço exibido são iguais' });

      if (page.amount && qr.amount) {
        if (!sameAmount(page.amount, qr.amount)) {
          checks.push({ name: 'Valor', status: 'fail', detail: 'QR ' + qr.amount + ' · página ' + page.amount });
          return { ...base, level: 'red', title: 'Valor divergente', reason: 'O QR Code pede ' + qr.amount + ', mas a página mostra ' + page.amount + '. Não envie o pagamento.' };
        }
        checks.push({ name: 'Valor', status: 'ok', detail: qr.amount + ' no QR e na página' });
      } else if (page.amount && !qr.amount) {
        checks.push({ name: 'Valor', status: 'info', detail: 'O QR não traz valor; confira ' + page.amount + ' ' + (page.token || 'SOL') + ' no app da carteira' });
      }

      if (qr.splToken && page.token && /^SOL$/i.test(page.token)) {
        checks.push({ name: 'Token', status: 'fail', detail: 'QR usa token SPL; página diz SOL' });
        return { ...base, level: 'red', title: 'Token divergente', reason: 'A página fala em SOL, mas o QR Code pede um token SPL (' + qr.splToken + '). Não envie o pagamento.' };
      }

      if (known) {
        checks.push({ name: 'Referência', status: 'ok', detail: known.name });
        return { ...base, level: 'green', title: 'Identidade confirmada', reason: 'QR, endereço exibido e referência confiável coincidem.' };
      }
      return { ...base, level: 'consistent', title: 'QR e endereço conferem', reason: 'O QR Code leva ao mesmo endereço exibido na página. Isso não prova que a carteira pertence ao vendedor: confirme o destinatário por outro canal.' };
    }

    if (known) checks.push({ name: 'Referência', status: 'ok', detail: known.name });

    if (qr && !page) {
      checks.push({ name: 'Endereço exibido', status: 'warn', detail: 'A página não mostra um endereço para comparar' });
      if (known) return { ...base, level: 'green', title: 'Identidade confirmada', reason: 'Endereço correspondente à referência confiável.' };
      return { ...base, level: 'yellow', title: 'Verificação inconclusiva', reason: 'O QR Code leva a ' + qr.address + ', mas a página não mostra um endereço para comparar.' };
    }

    // Só texto na página
    if (ctx.qrRaw) {
      checks.push({ name: 'QR Code', status: 'warn', detail: 'Conteúdo não é um pagamento Solana reconhecido' });
      return { ...base, level: 'yellow', title: 'QR Code não reconhecido', reason: 'Há um QR Code na página, mas o conteúdo não é um endereço ou link Solana Pay (' + String(ctx.qrRaw).slice(0, 60) + '). Não dá para confirmar o destino.' };
    }
    checks.push({ name: 'QR Code', status: 'warn', detail: ctx.qrAttempted ? 'Não encontrado ou ilegível' : 'Não verificado' });
    if (known) return { ...base, level: 'green', title: 'Identidade confirmada', reason: 'Endereço correspondente à referência confiável (QR não verificado).' };
    return { ...base, level: 'yellow', title: 'Não foi possível ler o QR Code', reason: 'Endereço detectado (' + page.address + '), mas o QR Code não pôde ser lido para comparação. Confira manualmente.' };
  }

  root.SolGuardDetector = { validAddress, parse, extractFromText, compareSources, DEFAULT_REGISTRY };
})(globalThis);
