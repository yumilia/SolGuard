# SolGuard — Anti-Scam 1.5.1

Compara o endereço de carteira que a página de pagamento exibe com o destino do QR Code.

## Instalar
1. Extraia o zip.
2. Abra `chrome://extensions`, ative o **Modo do desenvolvedor**.
3. **Carregar sem compactação** e escolha a pasta extraída.

## Resultados
- **Vermelho**: o QR leva a outra carteira, outro valor ou outro token. Não pague.
- **Azul (QR e endereço conferem)**: QR e endereço exibido são iguais. Não prova que a carteira é do vendedor.
- **Amarelo**: não deu para comparar (QR ilegível, ausente ou que não é Solana).
- **Verde**: o endereço está na lista de referência (`DEFAULT_REGISTRY` em `solguard-core.js`).

## Como o QR é lido
1. Imagens, `<canvas>` e `<svg>` da página (jsQR).
2. Imagens de outro domínio são baixadas pelo service worker, sem cookies.
3. Último recurso: captura da aba visível, renovada a cada 6 segundos enquanto a aba estiver aberta. Entre uma captura e outra vale a última leitura (por até 20 s), para o resultado não oscilar.

Tudo roda localmente; nada é enviado a servidores.

## Limites
- Só compara o QR com o que o site mostra. Para confirmar que a carteira pertence ao vendedor, cadastre-a em `DEFAULT_REGISTRY` ou confirme por outro canal.
- QR que só aparece fora da área visível e não está em img/canvas/svg não é lido.

## Licenças
`jsQR.js` © Cosmo Wolfe, Apache License 2.0 (`jsQR-LICENSE.txt`).
