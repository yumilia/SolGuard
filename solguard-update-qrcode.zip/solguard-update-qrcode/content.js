(function () {
  'use strict';
  if (globalThis.__solguardLoaded) return;
  const D = globalThis.SolGuardDetector;
  if (!D) return;
  globalThis.__solguardLoaded = true;

  const REGISTRY = D.DEFAULT_REGISTRY;
  const PAY_WORDS = /(pagar|pagamento|pay\b|payment|checkout|invoice|fatura|cobran[cç]a|solana pay)/i;
  const SOLANA_HINT = /solana|\bSOL\b|phantom|solflare/i;
  const MIN_SIDE = 80, MAX_SIDE = 900, MAX_CANDIDATES = 8;
  const SHOT_OPTS = { maxSide: 3000, pad: 0, invert: false, noUpscale: true };
  const SHOT_EVERY_MS = 6000;   // intervalo mínimo entre capturas da aba
  const GOOD_TTL_MS = 20000;    // por quanto tempo vale a última leitura válida se a releitura falhar

  const imgCache = new Map();
  let running = false, rerun = false, timer = 0, lastRun = 0;
  let lastKey = '', hadResult = false;
  let lastShotAt = 0, lastPageAddr = null, lastGood = null;

  const send = msg => new Promise(resolve => {
    try { chrome.runtime.sendMessage(msg, r => { void chrome.runtime.lastError; resolve(r); }); }
    catch { resolve(undefined); }
  });

  async function ensureJsQR() {
    if (typeof globalThis.jsQR === 'function') return true;
    await send({ type: 'loadJsQR' });
    return typeof globalThis.jsQR === 'function';
  }

  const loadImage = url => new Promise((ok, no) => {
    const i = new Image();
    i.onload = () => ok(i);
    i.onerror = no;
    i.src = url;
  });

  // Desenha a origem numa tela com margem branca (zona silenciosa do QR) e decodifica com jsQR.
  function decodeSource(src, w, h, o = {}) {
    const maxSide = o.maxSide || MAX_SIDE, pad = o.pad ?? 32;
    const side = Math.max(w, h);
    let scale = 1;
    if (side > maxSide) scale = maxSide / side;
    else if (!o.noUpscale && side < 300) scale = Math.ceil(300 / side);
    const dw = Math.max(1, Math.round(w * scale)), dh = Math.max(1, Math.round(h * scale));
    const c = document.createElement('canvas');
    c.width = dw + pad * 2; c.height = dh + pad * 2;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
    ctx.imageSmoothingEnabled = scale < 1;
    ctx.drawImage(src, pad, pad, dw, dh);
    const data = ctx.getImageData(0, 0, c.width, c.height); // lança erro se a imagem for de outra origem
    const r = globalThis.jsQR(data.data, c.width, c.height, { inversionAttempts: o.invert === false ? 'dontInvert' : 'attemptBoth' });
    return r ? r.data : null;
  }

  // Imagem de outro domínio "suja" o canvas: o service worker baixa os bytes e devolve como data URL.
  async function decodeViaBackground(url) {
    if (!/^https?:/i.test(url)) return { raw: null, failed: false };
    const resp = await send({ type: 'fetchImage', url });
    if (!resp || !resp.ok) return { raw: null, failed: true };
    try {
      const img = await loadImage(resp.dataUrl);
      return { raw: decodeSource(img, img.naturalWidth, img.naturalHeight), failed: false };
    } catch { return { raw: null, failed: true }; }
  }

  async function decodeElement(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === 'img') {
      const key = el.currentSrc || el.src;
      if (!key || !el.complete || !el.naturalWidth) return null;
      if (imgCache.has(key)) return imgCache.get(key);
      let res;
      try { res = { raw: decodeSource(el, el.naturalWidth, el.naturalHeight), how: 'imagem' }; }
      catch {
        const b = await decodeViaBackground(key);
        res = { raw: b.raw, how: 'imagem de outro domínio' };
        if (b.failed) return res; // falha temporária: não vai para o cache, tenta de novo na próxima rodada
      }
      imgCache.set(key, res);
      return res;
    }
    if (tag === 'canvas') {
      try { return { raw: decodeSource(el, el.width, el.height), how: 'canvas' }; } catch { return null; }
    }
    if (tag === 'svg') {
      const r = el.getBoundingClientRect();
      const clone = el.cloneNode(true);
      clone.setAttribute('width', Math.round(r.width));
      clone.setAttribute('height', Math.round(r.height));
      if (!clone.getAttribute('xmlns')) clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
      try {
        const xml = new XMLSerializer().serializeToString(clone);
        const img = await loadImage('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml));
        return { raw: decodeSource(img, img.naturalWidth || r.width, img.naturalHeight || r.height), how: 'svg' };
      } catch { return null; }
    }
    return null;
  }

  async function scanDom() {
    const out = { parsed: [], raw: null, tried: 0 };
    const els = [...document.querySelectorAll('img,canvas,svg')].filter(el => {
      const r = el.getBoundingClientRect();
      const ratio = r.width / (r.height || 1);
      return r.width >= MIN_SIDE && r.height >= MIN_SIDE && r.width <= MAX_SIDE && r.height <= MAX_SIDE && ratio > 0.75 && ratio < 1.34;
    }).slice(0, MAX_CANDIDATES);
    for (const el of els) {
      out.tried++;
      let res = null;
      try { res = await decodeElement(el); } catch {}
      if (!res || !res.raw) continue;
      out.raw = out.raw || res.raw;
      const p = D.parse(res.raw, 'QR Code');
      if (p) { p.how = res.how; out.parsed.push(p); }
    }
    return out;
  }

  async function findQr(page) {
    if (!(await ensureJsQR())) return { qr: null, raw: null, attempted: false, how: null };
    const now = Date.now();
    const dom = await scanDom();
    const pick = (page && dom.parsed.find(p => p.address === page.address)) || dom.parsed[0] || null;
    if (pick) {
      lastGood = { qr: pick, how: pick.how, at: now };
      return { qr: pick, raw: dom.raw, attempted: true, how: pick.how };
    }

    let raw = dom.raw, attempted = dom.tried > 0, fresh = false;

    // QR fora de img/canvas/svg (fundo CSS, WebGL, imagem protegida): captura da aba visível,
    // no máximo a cada SHOT_EVERY_MS. Enquanto a página estiver aberta, a leitura é renovada.
    if (!raw && page && now - lastShotAt > SHOT_EVERY_MS && document.visibilityState === 'visible') {
      lastShotAt = now; attempted = true;
      const s = await send({ type: 'capture' });
      if (s && s.ok) {
        fresh = true;
        try {
          const img = await loadImage(s.dataUrl);
          const r2 = decodeSource(img, img.naturalWidth, img.naturalHeight, SHOT_OPTS);
          if (r2) {
            raw = r2;
            const qr = D.parse(r2, 'QR Code (captura da aba)');
            if (qr) {
              qr.how = 'captura da aba';
              lastGood = { qr, how: qr.how, at: Date.now() };
              return { qr, raw, attempted, how: qr.how };
            }
          }
        } catch {}
        lastGood = null; // captura feita e sem QR de pagamento: o QR anterior não está mais na tela
      }
    }

    // Sem leitura nova nesta rodada (captura ainda não liberada, aba em segundo plano...):
    // vale a última leitura válida por GOOD_TTL_MS, para o resultado não ficar oscilando.
    if (!raw && !fresh && lastGood && now - lastGood.at < GOOD_TTL_MS) {
      return { qr: lastGood.qr, raw: null, attempted: true, how: 'leitura anterior (' + lastGood.how + ')' };
    }
    return { qr: null, raw, attempted, how: null };
  }

  function pageText() {
    const text = document.body ? document.body.innerText : '';
    let values = '';
    try {
      values = [...document.querySelectorAll('input:not([type=password]),textarea')].map(e => e.value).filter(Boolean).join('\n');
    } catch {}
    return text + '\n' + values;
  }

  function badge(r) {
    document.querySelector('[data-solguard-badge]')?.remove();
    if (r.level === 'none') return;
    const colors = { red: '#c0405f', yellow: '#b8912f', consistent: '#3aa6b9', green: '#2e8f6f' };
    const e = document.createElement('div');
    e.dataset.solguardBadge = '1';
    e.textContent = '◈ SolGuard: ' + r.title;
    e.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:2147483647;padding:7px 10px;border-radius:999px;background:#161522;color:#fff;border:1px solid ' + (colors[r.level] || '#876c25') + ';font:700 12px system-ui;box-shadow:0 5px 16px #0008';
    document.documentElement.appendChild(e);
  }

  async function analyse() {
    if (running) { rerun = true; return; }
    running = true; lastRun = Date.now();
    try {
      const text = pageText();
      const ex = D.extractFromText(text);
      const gate = ex.addresses.length > 0 || SOLANA_HINT.test(text);

      let page = ex.primary ? { address: ex.primary, amount: ex.amount, token: ex.token, source: 'endereço exibido', all: ex.addresses } : null;
      if ((page && page.address) !== lastPageAddr) { lastGood = null; lastShotAt = 0; lastPageAddr = page ? page.address : null; }

      let scan = null;
      if (gate) scan = await findQr(page);

      // Um endereço solto numa página (explorer, blog) não é um pagamento.
      if (page && !(scan && scan.qr) && !ex.amount && !PAY_WORDS.test(text)) page = null;

      const r = gate
        ? D.compareSources(page, scan && scan.qr, REGISTRY, { qrAttempted: scan && scan.attempted, qrRaw: scan && scan.raw, how: scan && scan.how })
        : D.compareSources(null, null, REGISTRY);

      if (r.level === 'none' && !hadResult) return;

      const p = r.payment;
      const data = {
        level: r.level, title: r.title, reason: r.reason, checks: r.checks,
        address: p ? p.address : null, amount: p ? p.amount : null, token: p ? p.token : null,
        site: location.hostname, network: 'Solana', detectedAt: new Date().toISOString()
      };
      // O "como foi lido" não entra na chave: mudar de captura para leitura anterior não é uma mudança de resultado.
      const key = JSON.stringify([data.level, data.title, data.reason, data.address, data.amount, data.checks.map(c => c.name + c.status)]);
      if (key === lastKey) return;
      lastKey = key;
      hadResult = r.level !== 'none';
      badge(r);
      send({ type: 'analysis', data });
    } finally {
      running = false;
      if (rerun) { rerun = false; schedule(); }
    }
  }

  function schedule() {
    if (timer) return;
    const wait = Math.max(600, 2500 - (Date.now() - lastRun));
    timer = setTimeout(() => { timer = 0; analyse(); }, wait);
  }

  const isOwn = m => {
    const ns = [...m.addedNodes, ...m.removedNodes];
    return ns.length > 0 && ns.every(n => n.nodeType === 1 && n.hasAttribute('data-solguard-badge'));
  };

  schedule();
  new MutationObserver(muts => { if (!muts.every(isOwn)) schedule(); })
    .observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['src', 'href', 'value', 'data-clipboard-text'] });
})();
