const D = globalThis.SolGuardDetector;
const $ = id => document.getElementById(id);
const LEVEL_CLASS = { green: 'safe', consistent: 'neutral', yellow: 'warn', red: 'risk', none: 'neutral' };
const SEVERITY = { red: 4, yellow: 3, consistent: 2, green: 1, none: 0 };
const ICON = { ok: '✓', fail: '✕', warn: '!', info: 'i' };

// Tudo que vem da página entra por textContent (nunca innerHTML).
function render(v) {
  $('result').hidden = false;
  $('empty').hidden = true;
  const known = D.DEFAULT_REGISTRY[v.address];
  $('verdict').className = 'verdict ' + (LEVEL_CLASS[v.level] || 'neutral');
  $('verdict').textContent = v.title || 'Verificação inconclusiva';
  $('amount').textContent = v.amount ? v.amount + ' ' + (v.token || 'SOL') : 'Não informado';
  $('label').textContent = (known && known.name) || v.site || 'Desconhecido';
  $('address').textContent = v.address || '—';
  $('token').textContent = v.token || 'SOL';
  $('detail').textContent = v.reason || '';

  const list = $('checks');
  list.textContent = '';
  for (const c of v.checks || []) {
    const li = document.createElement('li');
    li.className = c.status;
    li.textContent = (ICON[c.status] || '•') + ' ' + c.name + ': ' + c.detail;
    list.appendChild(li);
  }
}

(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    const key = 'analysis:' + tab.id;
    const frames = Object.values((await chrome.storage.session.get(key))[key] || {});
    if (!frames.length) return;
    frames.sort((a, b) => (SEVERITY[b.level] || 0) - (SEVERITY[a.level] || 0)); // mostra o pior resultado
    render(frames[0]);
  } catch {}
})();

$('scan').onclick = () => {
  const parsed = D.parse($('payment').value.trim(), 'manual');
  if (!parsed) return render({ level: 'yellow', title: 'Inválido', reason: 'Endereço ou link incorreto.', address: '—', checks: [] });
  const known = D.DEFAULT_REGISTRY[parsed.address];
  render({
    level: known ? 'green' : 'yellow',
    title: known ? 'Identidade confirmada' : 'Endereço válido, identidade não verificada',
    reason: 'Este link leva ao endereço abaixo. Compare com o endereço mostrado pelo site antes de pagar.',
    address: parsed.address, amount: parsed.amount, token: parsed.token, site: 'Manual',
    checks: [{ name: 'Formato', status: 'ok', detail: 'Endereço Solana válido' }]
  });
};
